import os
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import TransformerConv, global_mean_pool
from torch_geometric.loader import DataLoader
from torch_geometric.data import InMemoryDataset
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
import numpy as np
import warnings
warnings.filterwarnings("ignore")


class FocalLossWithLogits(nn.Module):
    def __init__(self, gamma=2.0, pos_weight=None):
        super(FocalLossWithLogits, self).__init__()
        self.gamma = gamma
        self.pos_weight = pos_weight

    def forward(self, logits, targets):
        bce_loss = F.binary_cross_entropy_with_logits(logits, targets, reduction='none')
        probs = torch.sigmoid(logits)
        
        p_t = targets * probs + (1 - targets) * (1 - probs)
        focal_weight = (1 - p_t) ** self.gamma
        
        loss = focal_weight * bce_loss
        
        if self.pos_weight is not None:
            weight_mask = targets * self.pos_weight + (1 - targets) * 1.0
            loss = loss * weight_mask
            
        return loss.mean()

class TupleDataset(InMemoryDataset):
    def __init__(self, pt_path):
        super(TupleDataset, self).__init__(None)
        self.data, self.slices = torch.load(pt_path, weights_only=False)

class LatticeGNN(torch.nn.Module):
    def __init__(self, node_in_dim=14, edge_in_dim=41, hidden_dim=128, dropout_rate=0.1): 
        super(LatticeGNN, self).__init__()
        # ��ͷע�������ƣ�ƴ�Ӷ�ͨ����ѧ�����ռ� (heads=4, concat=True)
        self.conv1 = TransformerConv(node_in_dim, hidden_dim // 4, heads=4, concat=True, edge_dim=edge_in_dim, dropout=dropout_rate)
        self.conv2 = TransformerConv(hidden_dim, hidden_dim // 4, heads=4, concat=True, edge_dim=edge_in_dim, dropout=dropout_rate)
        self.conv3 = TransformerConv(hidden_dim, hidden_dim // 4, heads=4, concat=True, edge_dim=edge_in_dim, dropout=dropout_rate)
        self.global_context_1 = nn.Linear(hidden_dim, hidden_dim)
        self.global_context_2 = nn.Linear(hidden_dim, hidden_dim)      
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim * 2 + edge_in_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(hidden_dim // 2, 1)
        )

    def forward(self, data):
        x, edge_index, edge_attr = data.x, data.edge_index, data.edge_attr
        

        if hasattr(data, 'batch') and data.batch is not None:
            batch_idx = data.batch
        else:
            batch_idx = torch.zeros(x.size(0), dtype=torch.long, device=x.device)
        
        x1 = F.relu(self.conv1(x, edge_index, edge_attr))
        
        g_emb1 = F.relu(self.global_context_1(global_mean_pool(x1, batch_idx)))
        x1 = x1 + g_emb1[batch_idx] 
        x2 = F.relu(self.conv2(x1, edge_index, edge_attr))
        
        g_emb2 = F.relu(self.global_context_2(global_mean_pool(x2, batch_idx)))
        x2 = x2 + g_emb2[batch_idx]
        
        x3 = self.conv3(x2, edge_index, edge_attr) + x1 
        
        row, col = edge_index[0], edge_index[1]
        edge_features = torch.cat([x3[row], x3[col], edge_attr], dim=-1)
        return self.classifier(edge_features).squeeze(-1)

def visualize_validation(model, data, epoch, device, threshold=0.5):
    model.eval()
    data = data.to(device)
    with torch.no_grad():
        probs = torch.sigmoid(model(data)).cpu().numpy().flatten()
    
    nodes = data.x.cpu().numpy()[:, :2] 
    edge_index = data.edge_index.t().cpu().numpy()
    
    y_full = torch.zeros(data.edge_mask.size(0), dtype=data.y.dtype, device=data.y.device)
    y_full[data.edge_mask] = data.y
    y_full[~data.edge_mask] = data.y
    labels = y_full.cpu().numpy().flatten()
    
    edge_dict = {}
    for i, (u, v) in enumerate(edge_index):
        edge_key = (min(u, v), max(u, v))
        if edge_key not in edge_dict:
            edge_dict[edge_key] = {'line': [nodes[u], nodes[v]], 'label': labels[i], 'probs': []}
        edge_dict[edge_key]['probs'].append(probs[i])
            
    clean_lines, clean_labels, clean_probs = [], [], []
    for key, val in edge_dict.items():
        clean_lines.append(val['line'])
        clean_labels.append(val['label'])
        clean_probs.append(np.max(val['probs']))
            
    clean_labels, clean_probs = np.array(clean_labels), np.array(clean_probs)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 8))
    
    lines_ok = [clean_lines[i] for i in range(len(clean_lines)) if clean_labels[i] <= 0.5]
    lines_broken = [clean_lines[i] for i in range(len(clean_lines)) if clean_labels[i] > 0.5]
    ax1.add_collection(LineCollection(lines_ok, colors='silver', linewidths=0.5, alpha=0.6))
    if lines_broken:
        ax1.add_collection(LineCollection(lines_broken, colors='blue', linewidths=1.8, alpha=0.9))
    ax1.set_title("Abaqus Ground Truth (Blue = Fractured)")
    
    ax2.add_collection(LineCollection(clean_lines, colors='silver', linewidths=0.5, alpha=0.2))
    high_risk_indices = [i for i in range(len(clean_probs)) if clean_probs[i] >= threshold]
    
    if high_risk_indices:
        pred_lines_high = [clean_lines[i] for i in high_risk_indices]
        pred_probs_high = clean_probs[high_risk_indices]
        dynamic_linewidths = 0.8 + 1.2 * pred_probs_high
        
        lc_pred = LineCollection(pred_lines_high, cmap='Blues', array=pred_probs_high, linewidths=dynamic_linewidths, alpha=0.9)
        lc_pred.set_clim(0.0, 1.0)
        ax2.add_collection(lc_pred)
        fig.colorbar(lc_pred, ax=ax2, label='Fracture Probability')
    else:
        ax2.text(0.5, 0.5, f"No Cracks Pred >= {threshold} Yet", transform=ax2.transAxes, 
                 ha="center", va="center", color="gray", fontsize=12)

    ax2.set_title(f"GNN Prediction (Filtered >= {threshold}, Epoch {epoch})")
    
    for ax in [ax1, ax2]:
        ax.set_aspect('equal')
        ax.autoscale()
        ax.axis('off')
    plt.savefig(f"local_predict_epoch_{epoch:02d}.png", dpi=150, bbox_inches='tight')
    plt.close()

def main():
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f" �������ڶ��������� GNN ǿ��ѵ��")
    print(f" ���ļ�����ٿ�: {device} ({torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU'})")

    processed_pt_path = r".\truss_strut_graph_data_v4.pt"
    
    if not os.path.exists(processed_pt_path):
        raise FileNotFoundError(f"δ���ڸ�·���ҵ�ǰ������ͳһ����ļ�: {processed_pt_path}")
        
    print(f"[DATASET] ����ֱ�Ӷ�ȡ���ļ�����ȫ�����ݼ�...")
    full_dataset = TupleDataset(processed_pt_path)
    total_samples = len(full_dataset)
    print(f"[DATASET] �ɹ����룬�ܼ�: {total_samples} �����ģ��")
    
    torch.manual_seed(42)  
    indices = torch.randperm(total_samples).tolist()
    
    split_idx = int(total_samples * 0.8)
    train_indices = indices[:split_idx]
    val_indices = indices[split_idx:]
    
    train_dataset = full_dataset[train_indices]
    val_dataset = full_dataset[val_indices]
    
    print(f"   -> ������ϣ�ѵ���� {len(train_dataset)} �� | ��֤�� {len(val_dataset)} ��")
    
    train_loader = DataLoader(train_dataset, batch_size=16, shuffle=True, num_workers=8, pin_memory=True)
    val_loader = DataLoader(val_dataset, batch_size=8, shuffle=False, num_workers=8, pin_memory=True)
    
    print(" ����ɨ�����ݼ��Լ�����Ѷ��ѳͷ�Ȩ��...")
    num_pos, num_neg = 0, 0
    for data in train_dataset:
        num_pos += (data.y > 0.5).sum().item()
        num_neg += (data.y <= 0.5).sum().item()
    
    calculated_weight = num_neg / max(num_pos, 1)
    print(f"   [ͳ�ƽ��] ȫ��δ���ѱ�: {num_neg} | �Ѷ��ѱ�: {num_pos}")
    print(f"   [Ȩ�ؼ���] �Զ�������Ӧʽ��׼Ȩ�� = {calculated_weight:.2f}")
    
    model = LatticeGNN(node_in_dim=14, edge_in_dim=41, dropout_rate=0.1).to(device)
    
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=15, gamma=0.5)
    
    pos_weight_tensor = torch.tensor([calculated_weight], dtype=full_dataset[0].y.dtype, device=device)
    criterion = FocalLossWithLogits(gamma=2.0, pos_weight=pos_weight_tensor)
    
    watch_sample = val_dataset[0]
    epochs = 45
    best_val_loss = float('inf') 
    
    for epoch in range(1, epochs + 1):
        model.train()
        train_loss = 0
        for batch in train_loader:
            batch = batch.to(device)
            optimizer.zero_grad()
            
            output = model(batch)
            
            y_full = torch.zeros(batch.edge_mask.size(0), dtype=batch.y.dtype, device=batch.y.device)
            y_full[batch.edge_mask] = batch.y
            y_full[~batch.edge_mask] = batch.y
            
            loss = criterion(output.to(y_full.dtype), y_full)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()
            
        model.eval()
        val_loss = 0
        with torch.no_grad():
            for batch in val_loader:
                batch = batch.to(device)
                output = model(batch)
                
                y_full = torch.zeros(batch.edge_mask.size(0), dtype=batch.y.dtype, device=batch.y.device)
                y_full[batch.edge_mask] = batch.y
                y_full[~batch.edge_mask] = batch.y
                
                val_loss += criterion(output.to(y_full.dtype), y_full).item()
        
        scheduler.step()
        current_lr = optimizer.param_groups[0]['lr']
                
        avg_train_loss = train_loss / len(train_loader)
        avg_val_loss = val_loss / len(val_loader)
        print(f"Epoch {epoch:02d} | LR: {current_lr:.5f} | Train Loss: {avg_train_loss:.4f} | Val Loss: {avg_val_loss:.4f}")
        
        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            torch.save(model.state_dict(), 'best_lattice_gnn.pth')
            print(f"    ��⵽���͵���֤����ʧ������ģ���ѱ�����: ./best_lattice_gnn.pth")
        
        if epoch == 1 or epoch % 5 == 0:
            visualize_validation(model, watch_sample, epoch, device, threshold=0.5)

    print("\n ѵ��ȫ��������")
    print(f" ����ģ�͵���֤�� Loss Ϊ: {best_val_loss:.4f}�����ڵ�ǰ�ļ�����Ѱ�� 'best_lattice_gnn.pth'��")

if __name__ == "__main__":
    main()