# -*- coding: utf-8 -*-
"""
data_utilsjian.py - Edge-level Prediction · Mesh Coarsening · Dual-circle Geometric Features
==========================================================================================

Node features (11D): coordinates + degree + distance + defect features + topological distance

Edge features (39D = basic 1D + direction 4D + dual-circle 20D + defect local coordinates 14D):
  0   length_norm            Normalized strut length
  1-4 dir_4d                 Direction one-hot: horizontal/vertical/positive-diagonal/negative-diagonal
  5-13 Defect 1 (9 items): dist_center/signed_dist/du/dv/intersect/frac_in/cos_angle/min_d/max_d
 14-22 Defect 2 (9 items): same as above
 23-24 Coupling (2 items): dist1_minus_dist2 / dist_to_ligament
 25-38 Defect local coordinates (14 items):
       Per defect (6 items): signed_dist/r, abs_dist/r, crosses_boundary,
       min_endpoint_dist/r, radial_align, tangent_align
       Dual defect (2 items): ligament projection / ligament corridor distance

Labels:
  - y: Final fracture (≥20% element failure → critical_ratio ≥ 0.2)

Workflow:
  1. Fixed template reconstruction → missing edge identification
  2. K-means dual-circle fitting
  3. Dual-circle geometric features → edge features
  4. Direction one-hot → edge features
"""


import os
import json
import re
import math
import numpy as np
import pandas as pd
import networkx as nx
import torch
from collections import defaultdict, Counter
from tqdm import tqdm
from torch_geometric.data import Data, InMemoryDataset
from sklearn.cluster import DBSCAN, KMeans
from scipy.spatial import cKDTree

DATA_CACHE_VERSION = 4

def _norm_cache_key(norm_params):
    return json.dumps(norm_params or {}, sort_keys=True, ensure_ascii=True)


# ==================== Configuration (can be overridden by configjian.py) ====================
try:
    from configjian import (
        RAW_DATA_DIR, INP_DATA_DIR, DATA_ROOT, LABEL_SMOOTHING,
        COLLINEARITY_THRESHOLD, CHORD_HORIZONTAL_THRESHOLD,
        DBSCAN_EPS, DBSCAN_MIN_SAMPLES,
        TOPO_DIST_MAX_HOPS, TOPO_DIST_DEFAULT,
        PROXIMITY_EPS, PROXIMITY_CLIP,
    )
except ImportError:
    RAW_DATA_DIR = "./chromeDownload/new/RAW_DATA_DIR"
    INP_DATA_DIR = "./chromeDownload/new/INP_DATA_DIR"
    DATA_ROOT = os.path.dirname(os.path.abspath(__file__))
    LABEL_SMOOTHING = 0.0
    COLLINEARITY_THRESHOLD = 0.99
    CHORD_HORIZONTAL_THRESHOLD = 30.0
    DBSCAN_EPS = 15.0
    DBSCAN_MIN_SAMPLES = 2
    TOPO_DIST_MAX_HOPS = 50.0
    TOPO_DIST_DEFAULT = 99.0
    PROXIMITY_EPS = 1e-3
    PROXIMITY_CLIP = 10.0


# ======================================================================
#  INP File Parsing (V2 Deep Parsing, supports SET references / GENERATE syntax)
# ======================================================================
def _read_inp_lines(inp_path: str):
    """Read INP file, return (lines, parsed_sets)."""
    if not os.path.exists(inp_path):
        return [], {}

    with open(inp_path, "r", encoding="utf-8", errors="ignore") as f:
        lines = f.readlines()

    sets = {}
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        m_set = re.match(r"\*(NSET|ELSET)\b", line, re.IGNORECASE)
        if m_set:
            set_type = m_set.group(1).upper()
            m_name = re.search(r"(?:NSET|ELSET)\s*=\s*(\S+)", line, re.IGNORECASE)
            set_name = m_name.group(1).strip(",") if m_name else f"__{set_type}_{len(sets)}"
            m_gen = re.search(r"GENERATE", line, re.IGNORECASE)
            if m_gen and i + 1 < len(lines) and not lines[i + 1].strip().startswith("*"):
                parts = lines[i + 1].strip().split(",")
                try:
                    start, end, inc = [int(x.strip()) for x in parts[:3]]
                    sets[set_name] = list(range(start, end + 1, inc))
                except (ValueError, IndexError):
                    sets[set_name] = []
            else:
                members = []
                j = i + 1
                while j < len(lines) and not lines[j].strip().startswith("*"):
                    for v in lines[j].strip().split(","):
                        v = v.strip()
                        if v:
                            try:
                                members.append(int(v))
                            except ValueError:
                                pass
                    j += 1
                sets[set_name] = members
        i += 1

    return lines, sets


def _resolve_set_tokens(token_str: str, parsed_sets: dict):
    """Parse a token (may be number or SET name) into integer list."""
    token_str = token_str.strip().rstrip(",")
    try:
        return [int(token_str)]
    except ValueError:
        pass
    if token_str in parsed_sets:
        return list(parsed_sets[token_str])
    return []


def parse_inp_nodes_and_elements(inp_path: str):
    """
    Extract node coordinates and element connectivity from INP file.
    Returns:
        nodes  : dict  {node_id: [x, y]}
        edges  : list  [(elem_id, node1, node2), ...]
    """
    lines, _ = _read_inp_lines(inp_path)
    if not lines:
        return {}, []

    nodes = {}
    edges = []
    current_section = None

    for line in lines:
        line = line.strip()
        line_lower = line.lower()

        if line.startswith('*Node'):
            current_section = 'node'
        elif line.startswith('*Element'):
            current_section = 'element'
        elif line.startswith('*'):
            if current_section in ('node', 'element'):
                current_section = None
        elif line and current_section:
            parts = [p.strip() for p in line.split(',')]
            if current_section == 'node' and len(parts) >= 3:
                try:
                    node_id = int(float(parts[0]))
                    nodes[node_id] = [float(parts[1]), float(parts[2])]
                except (ValueError, IndexError):
                    continue
            elif current_section == 'element' and len(parts) >= 3:
                try:
                    edges.append((int(float(parts[0])), int(float(parts[1])), int(float(parts[2]))))
                except (ValueError, IndexError):
                    continue

    return nodes, edges


def parse_inp_boundary_conditions(inp_path: str):
    """Extract boundary conditions (fixed node sets) from Abaqus INP file."""
    bc_records = []
    lines, parsed_sets = _read_inp_lines(inp_path)
    if not lines:
        return []

    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if re.match(r"\*BOUNDARY\b", line, re.IGNORECASE):
            j = i + 1
            while j < len(lines) and not lines[j].strip().startswith("*"):
                data_line = lines[j].strip()
                if not data_line:
                    j += 1
                    continue
                parts = [p.strip() for p in data_line.split(",")]
                if len(parts) >= 2:
                    tokens = _resolve_set_tokens(parts[0], parsed_sets)
                    for node_label in tokens:
                        bc_records.append(node_label)
                j += 1
        i += 1

    return list(set(bc_records))


def parse_inp_loads(inp_path: str, primary_dof: int = 2):
    """
    Extract loads from Abaqus INP file (supports *CLOAD and *Boundary amplitude formats).

    - *CLOAD: column 3 is force/displacement magnitude
    - *Boundary, amplitude=...: column 4 is displacement magnitude (displacement-controlled loading)
      Note: 3-column Boundary is fixed constraint (skip),
            4+ column Boundary has magnitude (extract).
    """
    load_records = defaultdict(dict)
    lines, parsed_sets = _read_inp_lines(inp_path)
    if not lines:
        return {}

    i = 0
    while i < len(lines):
        line = lines[i].strip()
        # *CLOAD (force loading)
        if re.match(r"\*CLOAD\b", line, re.IGNORECASE):
            j = i + 1
            while j < len(lines) and not lines[j].strip().startswith("*"):
                data_line = lines[j].strip()
                if not data_line:
                    j += 1
                    continue
                parts = [p.strip() for p in data_line.split(",")]
                if len(parts) >= 3:
                    tokens = _resolve_set_tokens(parts[0], parsed_sets)
                    try:
                        dof = int(parts[1].strip())
                        magnitude = float(parts[2].strip())
                    except (ValueError, IndexError):
                        j += 1
                        continue
                    for node_label in tokens:
                        load_records[node_label][dof] = magnitude
                j += 1
        # *Boundary with amplitude (col4 is magnitude, displacement loading)
        elif re.match(r"\*BOUNDARY\b", line, re.IGNORECASE) and "amplitude" in line.lower():
            j = i + 1
            while j < len(lines) and not lines[j].strip().startswith("*"):
                data_line = lines[j].strip()
                if not data_line:
                    j += 1
                    continue
                parts = [p.strip() for p in data_line.split(",")]
                # 4+ columns: nset, dof1, dof2, magnitude = displacement loading
                if len(parts) >= 4:
                    tokens = _resolve_set_tokens(parts[0], parsed_sets)
                    try:
                        dof = int(parts[1].strip())
                        magnitude = float(parts[3].strip())
                    except (ValueError, IndexError):
                        j += 1
                        continue
                    for node_label in tokens:
                        load_records[node_label][dof] = magnitude
                j += 1
        i += 1

    # Take primary DOF load for each node，Take max absolute value if not exist
    result = {}
    for node_label, dof_map in load_records.items():
        if primary_dof in dof_map:
            result[node_label] = dof_map[primary_dof]
        elif dof_map:
            result[node_label] = max(dof_map.values(), key=abs)
    return result


# ======================================================================
#  Step 1: Fixed Template Reconstruction + Missing Edge Identification
# ======================================================================
def _infer_lattice_spacing(nodes_dict):
    """
    Infer lattice basic spacing unit from sample node coordinates.
    Principle: All node coordinates in regular triangular grid are integer multiples of basic unit.
    Use GCD method to find maximum common divisor as minimum spacing.
    """
    coords = np.array(list(nodes_dict.values()), dtype=np.float64)
    xs, ys = coords[:, 0], coords[:, 1]

    # x-direction spacing candidates
    unique_xs = np.unique(xs)
    unique_ys = np.unique(ys)

    if len(unique_xs) < 2 or len(unique_ys) < 2:
        # Fallback: hard-coded default values
        return 1.0, np.sqrt(3) / 2.0

    # Find minimum spacing between adjacent points (x and y directions)
    dx_candidates = np.diff(np.sort(unique_xs))
    dy_candidates = np.diff(np.sort(unique_ys))

    dx = float(np.min(dx_candidates[dists_gt_zero(dx_candidates)])) if any(dx_candidates > 1e-6) else 1.0
    dy = float(np.min(dy_candidates[dists_gt_zero(dy_candidates)])) if any(dy_candidates > 1e-6) else np.sqrt(3) / 2.0

    return dx, dy


def dists_gt_zero(arr):
    return arr > 1e-6


COORD_KEY_DECIMALS = 6
_MESH_TEMPLATE_CACHE = {}


def _coord_key(x, y, ndigits=COORD_KEY_DECIMALS):
    return (round(float(x), ndigits), round(float(y), ndigits))


def build_mesh_template(nodes_dict):
    """
    Infer lattice parameters from sample node coordinates and reconstruct complete template.

    KD-tree accelerates "grid position → nearest actual node" lookup (replaces O(n×m) inner scan).
    Only creates template edges for nodes that exist in nodes_dict, ensuring correct count.

    Returns:
        template_nodes   : dict  {(gi, gj): (x, y)}  lattice coords → physical coords
        template_edges   : set   frozenset({n1_phys, n2_phys})  all template edges
        nx, ny           : int   inferred lattice dimensions
        phys_to_gi       : dict  physical ID → lattice coords
    """
    # Generate cache key
    coords = np.array(list(nodes_dict.values()), dtype=np.float64)
    # Convert values from list to tuple to make cache key hashable
    cache_key = tuple(sorted((k, tuple(v)) for k, v in nodes_dict.items()))
    
    # Check cache
    if cache_key in _MESH_TEMPLATE_CACHE:
        return _MESH_TEMPLATE_CACHE[cache_key]

    x_min, x_max = coords[:, 0].min(), coords[:, 0].max()
    y_min, y_max = coords[:, 1].min(), coords[:, 1].max()

    dx, dy = _infer_lattice_spacing(nodes_dict)

    nx = int(round((x_max - x_min) / dx))
    ny = int(round((y_max - y_min) / dy))
    nx = max(nx, 1)
    ny = max(ny, 1)

    # ---- KD-tree: Build physical node coordinate index for fast lookup ----
    phys_ids = np.array(list(nodes_dict.keys()), dtype=object)
    kdtree = cKDTree(coords)

    # Generate all grid point coordinates
    gx_s = x_min + np.arange(nx + 1) * dx
    gy_s = y_min + np.arange(ny + 1) * dy
    gx_grid, gy_grid = np.meshgrid(gx_s, gy_s, indexing='ij')
    grid_coords = np.stack([gx_grid.ravel(), gy_grid.ravel()], axis=1)  # (M, 2)
    dists, idxs = kdtree.query(grid_coords, k=1)
    matched_ids = phys_ids[idxs]  # Nearest physical node ID for each grid point

    TOL = 1e-3
    virtual_mask = dists > TOL

    # Reconstruct template_nodes and phys_to_gi
    template_nodes = {}
    phys_to_gi = {}
    for m, (gi, gj) in enumerate(zip(np.repeat(np.arange(nx + 1), ny + 1),
                                       np.tile(np.arange(ny + 1), nx + 1))):
        gi_i, gj_j = int(gi), int(gj)
        key = (gi_i, gj_j)
        template_nodes[key] = (float(grid_coords[m, 0]), float(grid_coords[m, 1]))
        phys_to_gi[matched_ids[m]] = key

    # Index formula: m = gi * (ny+1) + gj
    def m_idx(gi, gj):
        return gi * (ny + 1) + gj

    # Build template edges: only connect actual nodes (four directions)
    template_edges = set()
    for gi in range(nx + 1):
        for gj in range(ny + 1):
            m_i = m_idx(gi, gj)
            phys_i = matched_ids[m_i]
            if virtual_mask[m_i]:
                continue  # Skip: no corresponding actual node for this grid point

            # Right
            if gi < nx:
                phys_r = matched_ids[m_idx(gi + 1, gj)]
                if not virtual_mask[m_idx(gi + 1, gj)]:
                    template_edges.add(frozenset({phys_i, phys_r}))
            # Up
            if gj < ny:
                phys_u = matched_ids[m_idx(gi, gj + 1)]
                if not virtual_mask[m_idx(gi, gj + 1)]:
                    template_edges.add(frozenset({phys_i, phys_u}))
            # Upper-right diagonal
            if gi < nx and gj < ny:
                phys_d = matched_ids[m_idx(gi + 1, gj + 1)]
                if not virtual_mask[m_idx(gi + 1, gj + 1)]:
                    template_edges.add(frozenset({phys_i, phys_d}))
            # Lower-right diagonal
            if gi < nx and gj > 0:
                phys_d2 = matched_ids[m_idx(gi + 1, gj - 1)]
                if not virtual_mask[m_idx(gi + 1, gj - 1)]:
                    template_edges.add(frozenset({phys_i, phys_d2}))

    # Cache result
    result = (template_nodes, template_edges, nx, ny, phys_to_gi)
    _MESH_TEMPLATE_CACHE[cache_key] = result
    return result


def extract_sample_mesh_edges(nodes_dict, edges_list):
    """
    Convert sample edge list to frozenset (undirected, based on physical node IDs).
    """
    sample_edges = set()
    for elem_id, n1, n2 in edges_list:
        if n1 in nodes_dict and n2 in nodes_dict:
            sample_edges.add(frozenset({n1, n2}))
    return sample_edges


def find_missing_template_edges(template_nodes, template_edges, sample_edges, nodes_dict):
    """
    Take difference of template edges and sample edges → missing edges (midpoints are defect boundary candidates).
    """
    missing_edges = []
    for edge in template_edges - sample_edges:
        nodes_list = list(edge)
        n1, n2 = nodes_list[0], nodes_list[1]

        if isinstance(n1, str) and n1.startswith('_V_'):
            # Virtual node: parse (gi, gj) from "_V_gi_gj"
            _, gi, gj = n1.rsplit('_', 2)
            c1 = np.array(template_nodes[(int(gi), int(gj))], dtype=np.float64)
        else:
            c1 = np.array(nodes_dict[n1], dtype=np.float64)

        if isinstance(n2, str) and n2.startswith('_V_'):
            _, gi, gj = n2.rsplit('_', 2)
            c2 = np.array(template_nodes[(int(gi), int(gj))], dtype=np.float64)
        else:
            c2 = np.array(nodes_dict[n2], dtype=np.float64)

        midpoint = (c1 + c2) / 2.0
        missing_edges.append((midpoint, n1, n2))
    return missing_edges


# ======================================================================
#  Step 2: Dual-circle Fitting (Based on Missing Edge Midpoints)
# ======================================================================
def fit_dual_circles(missing_edges):
    """
    Fit two circular hole defects using midpoints of missing edges.

    Algorithm:
      1. K-means k=2 clustering (midpoint coordinates)
      2. Estimate circle center using mean for each cluster
      3. Radius = high percentile (90%) of distances from center to midpoints
      4. Sort by cx (x-coordinate) in ascending order

    Returns:
        defects : list  [{cx, cy, r}, ...]  two defects, sorted by cx
    """
    if len(missing_edges) < 4:
        # Insufficient data, fallback to simple estimation
        midpoints = np.array([m for m, _, _ in missing_edges])
        if len(midpoints) == 0:
            return [{'cx': 0, 'cy': 0, 'r': 5}]
        cx, cy = midpoints[:, 0].mean(), midpoints[:, 1].mean()
        r = float(np.max(np.linalg.norm(midpoints - [cx, cy], axis=1)))
        return [{'cx': cx, 'cy': cy, 'r': r}]

    midpoints = np.array([m for m, _, _ in missing_edges])

    # K-means k=2 (using sklearn)
    kmeans = KMeans(n_clusters=2, random_state=42, n_init=10)
    labels = kmeans.fit_predict(midpoints)

    defects = []
    for cluster_id in range(2):
        cluster_points = midpoints[labels == cluster_id]
        cx, cy = cluster_points[:, 0].mean(), cluster_points[:, 1].mean()
        dists = np.linalg.norm(cluster_points - [cx, cy], axis=1)
        # Use 90th percentile to estimate radius, leave some margin
        r = float(np.percentile(dists, 90))
        defects.append({'cx': cx, 'cy': cy, 'r': r})

    # Sort by cx in ascending order
    defects.sort(key=lambda d: d['cx'])
    return defects


# ======================================================================
#  Mesh Coarsening: Collinear Elements → Macro Struts
# ======================================================================
def group_elements_into_struts(nodes, edges):
    """
    Merge collinear fine-grained FEM elements into macro physical struts.

    Algorithm:
      1. Build mesh graph with NetworkX
      2. Identify physical joints (degree ≠ 2, or collinearity direction change points)
      3. Track along collinear paths from joints, merge elements into struts

    Returns:
        struts    : list[dict]  each strut contains {u, v, elem_ids, length, vec}
        joint_map : dict        physical node ID → joint index
    """
    G = nx.Graph()
    for eid, n1, n2 in edges:
        if n1 not in nodes or n2 not in nodes:
            continue
        G.add_edge(n1, n2, elem_id=eid)

    # Identify joints
    joints = []
    for n in G.nodes():
        neighbors = list(G.neighbors(n))
        degree = len(neighbors)

        if degree != 2:
            joints.append(n)
        else:
            n_prev, n_next = neighbors[0], neighbors[1]
            try:
                v1 = np.array(nodes[n]) - np.array(nodes[n_prev])
                v2 = np.array(nodes[n_next]) - np.array(nodes[n])
                v1 = v1 / (np.linalg.norm(v1) + 1e-8)
                v2 = v2 / (np.linalg.norm(v2) + 1e-8)
                if np.dot(v1, v2) < COLLINEARITY_THRESHOLD:
                    joints.append(n)
            except KeyError:
                continue

    # Path tracing to generate struts
    struts = []
    processed_edges = set()
    joint_map = {nid: i for i, nid in enumerate(joints)}

    for start_node in joints:
        neighbors = list(G.neighbors(start_node))
        for next_node in neighbors:
            edge_key = tuple(sorted((start_node, next_node)))
            if edge_key in processed_edges:
                continue

            curr = start_node
            following = next_node
            path_elems = [G[curr][following]['elem_id']]
            processed_edges.add(edge_key)

            while following not in joints:
                prev = curr
                curr = following
                nbs = list(G.neighbors(curr))
                if len(nbs) != 2:
                    break
                future = nbs[0] if nbs[0] != prev else nbs[1]
                edge_key_inner = tuple(sorted((curr, future)))
                path_elems.append(G[curr][future]['elem_id'])
                processed_edges.add(edge_key_inner)
                following = future

            end_node = following

            p_s = np.array(nodes[start_node])
            p_e = np.array(nodes[end_node])
            vec = p_e - p_s
            length = np.linalg.norm(vec)

            struts.append({
                'u': joint_map[start_node],
                'v': joint_map[end_node],
                'elem_ids': path_elems,
                'length': length,
                'vec': vec / (length + 1e-8)
            })

    return struts, joint_map


# ======================================================================
#  Strut Type Classification (Structural Identity)
# ======================================================================
def _classify_strut_directions(struts, joint_map, nodes_dict):
    """
    Classify each strut into 4 principal directions of triangular lattice (one-hot encoding).

    Direction determination: Compare strut vector cosine similarity with 4 lattice directions,
    take argmax as direction ID:
      0 = horizontal       (dx, 0)
      1 = vertical         (0, dy)
      2 = positive diagonal (1, 1)
      3 = negative diagonal (1, -1)

    Returns:
        strut_dirs : np.ndarray (num_struts, 4)  4D one-hot direction for each strut
    """
    if not struts:
        return np.zeros((0, 4), dtype=np.float32)

    num_struts = len(struts)

    # 4 lattice principal directions (unnormalized)
    canonical_dirs = np.array([
        [1.0, 0.0],   # horizontal
        [0.0, 1.0],   # vertical
        [1.0, 1.0],   # positive diagonal
        [1.0, -1.0],  # negative diagonal
    ], dtype=np.float64)
    # Normalize
    norms = np.linalg.norm(canonical_dirs, axis=1, keepdims=True)
    canonical_dirs /= norms

    strut_dirs = np.zeros((num_struts, 4), dtype=np.float32)
    for i, strut in enumerate(struts):
        vec = np.array(strut['vec'], dtype=np.float64)
        # Compute cosine similarity with 4 directions (absolute value, direction-independent)
        sims = np.abs(canonical_dirs @ vec)
        dir_id = int(np.argmax(sims))
        strut_dirs[i, dir_id] = 1.0

    return strut_dirs


# ======================================================================
#  Topological Force Flow Feature Computation
# ======================================================================
def compute_topology_features(G, joint_map, fixed_nodes, load_dict):
    """Compute topological hop distances from nodes to physical boundaries"""
    fixed_indices = [joint_map[n] for n in fixed_nodes if n in joint_map]
    load_indices = [joint_map[n] for n in load_dict.keys() if n in joint_map]
    
    num_nodes = len(G.nodes())
    dist_to_fixed = {i: TOPO_DIST_DEFAULT for i in range(num_nodes)}
    dist_to_load = {i: TOPO_DIST_DEFAULT for i in range(num_nodes)}
    
    # Topological distance: to fixed ends
    if fixed_indices:
        for f_idx in fixed_indices:
            if f_idx in G:
                lengths = nx.single_source_shortest_path_length(G, f_idx)
                for node, d in lengths.items():
                    dist_to_fixed[node] = min(dist_to_fixed[node], float(d))

    # Topological distance: to load ends
    if load_indices:
        for l_idx in load_indices:
            if l_idx in G:
                lengths = nx.single_source_shortest_path_length(G, l_idx)
                for node, d in lengths.items():
                    dist_to_load[node] = min(dist_to_load[node], float(d))
                    
    return dist_to_fixed, dist_to_load


# ======================================================================
# Defect info calculation (enhanced: distance + center + radius + relative vector)
# ======================================================================
def _compute_node_distances_dbscan(joint_map, nodes_dict, fixed_nodes,
                                   load_dict, struts):
    """
    Fallback：DBSCAN 聚类模式。
    仅在预处理计算 norm_params 时调用（此时尚未拟合双圆）。
    """
    num_joints = len(joint_map)
    if num_joints == 0:
        return {}, {}, 1.0, 1.0, [], {}, {}, {}

    joint_degrees = Counter()
    for strut in struts:
        joint_degrees[strut['u']] += 1
        joint_degrees[strut['v']] += 1
    max_deg = max(joint_degrees.values()) if joint_degrees else 1

    global_boundary_indices = set()
    for phys_id, idx in joint_map.items():
        if phys_id in fixed_nodes or phys_id in load_dict:
            global_boundary_indices.add(idx)

    all_coords = np.array([nodes_dict[pid] for pid in joint_map])
    x_min, x_max = all_coords[:, 0].min(), all_coords[:, 0].max()
    y_min, y_max = all_coords[:, 1].min(), all_coords[:, 1].max()
    margin_x = (x_max - x_min) * 0.05
    margin_y = (y_max - y_min) * 0.05
    for phys_id, idx in joint_map.items():
        x, y = nodes_dict[phys_id]
        if (x < x_min + margin_x or x > x_max - margin_x or
                y < y_min + margin_y or y > y_max - margin_y):
            global_boundary_indices.add(idx)

    defect_boundary_indices = set()
    for idx, deg in joint_degrees.items():
        if deg < max_deg and idx not in global_boundary_indices:
            defect_boundary_indices.add(idx)

    defect_clusters = []
    defect_positions = []
    for phys_id, idx in joint_map.items():
        if idx in defect_boundary_indices:
            defect_positions.append(nodes_dict[phys_id])
    defect_positions = np.array(defect_positions)

    if len(defect_positions) >= DBSCAN_MIN_SAMPLES:
        clustering = DBSCAN(eps=DBSCAN_EPS, min_samples=DBSCAN_MIN_SAMPLES).fit(defect_positions)
        for lbl in set(clustering.labels_):
            if lbl == -1:
                continue
            cluster_pts = defect_positions[clustering.labels_ == lbl]
            center = cluster_pts.mean(axis=0)
            radius = float(np.max(np.linalg.norm(cluster_pts - center, axis=1)))
            defect_clusters.append({'center': center, 'radius': max(radius, 1.0)})

    if not defect_clusters:
        defect_clusters = [{'center': all_coords.mean(axis=0), 'radius': 0.0}]

    dist_defect = {}
    closest_clusters = {}
    delta_x_def, delta_y_def = {}, {}
    for phys_id, idx in joint_map.items():
        coord = np.array(nodes_dict[phys_id])
        min_dist = float('inf')
        closest = defect_clusters[0]
        for cluster in defect_clusters:
            dist = np.linalg.norm(coord - cluster['center'])
            if dist < min_dist:
                min_dist = dist
                closest = cluster
        dist_defect[idx] = min_dist
        closest_clusters[idx] = closest
        delta_x_def[idx] = float(coord[0] - closest['center'][0])
        delta_y_def[idx] = float(coord[1] - closest['center'][1])

    load_node_ids = [nid for nid in load_dict.keys() if nid in nodes_dict]
    dist_load = {}
    if load_node_ids:
        load_positions = np.array([nodes_dict[nid] for nid in load_node_ids])
        for phys_id, idx in joint_map.items():
            coord = np.array(nodes_dict[phys_id])
            dists = np.linalg.norm(load_positions - coord, axis=1)
            dist_load[idx] = float(np.min(dists))
    else:
        diag = float(np.sqrt((x_max - x_min) ** 2 + (y_max - y_min) ** 2))
        for idx in range(num_joints):
            dist_load[idx] = max(diag, 1.0)

    max_dist_defect = max(dist_defect.values()) if dist_defect else 1.0
    max_dist_load = max(dist_load.values()) if dist_load else 1.0
    return (dist_defect, dist_load,
            max(max_dist_defect, 1.0), max(max_dist_load, 1.0),
            defect_clusters, closest_clusters, delta_x_def, delta_y_def)



def _compute_node_distances(joint_map, nodes_dict, fixed_nodes, load_dict,
                            defects=None, struts=None):
    """
    基于双圆缺陷计算每个铰接点到缺陷的距离和相关信息。

    若 defects=None（预处理阶段），fallback 到原 DBSCAN 逻辑。
    若 defects 已拟合（推理/训练阶段），使用双圆精确参数。

    参数：
        defects : list  fit_dual_circles 返回的 [{cx, cy, r}, ...]（已按 cx 排序）
        struts : list  仅在 fallback 模式（DBSCAN）时需要

    返回（兼容原接口）：
        dist_defect, dist_load, max_dist_defect, max_dist_load,
        defect_clusters（模拟格式，用于兼容）, closest_clusters, delta_x_def, delta_y_def
    """
    # ---- Fallback: DBSCAN mode (used during preprocessing for norm_params)----
    if defects is None:
        return _compute_node_distances_dbscan(joint_map, nodes_dict, fixed_nodes,
                                               load_dict, struts)

    # ---- Dual-circle precise mode ----
    num_joints = len(joint_map)
    if num_joints == 0:
        return {}, {}, 1.0, 1.0, [], {}, {}, {}

    # ---- 1. Calculate signed distance from each node to two circles ----
    dist_defect = {}           # Euclidean distance to nearest circle boundary
    signed_dist_defect = {}    # Signed distance to nearest circle boundary (negative = inside circle)
    closest_clusters = {}     # Nearest defect cluster for each node (simulated format)
    delta_x_def = {}
    delta_y_def = {}

    for phys_id, idx in joint_map.items():
        coord = np.array(nodes_dict[phys_id], dtype=np.float64)
        min_dist = float('inf')
        min_signed = float('inf')
        best_defect = defects[0]
        best_dx, best_dy = 0.0, 0.0

        for defct in defects:
            cx, cy, r = defct['cx'], defct['cy'], defct['r']
            dist_to_center = float(np.linalg.norm(coord - np.array([cx, cy])))
            signed = dist_to_center - r          # Signed: negative = inside circle
            dist_to_boundary = abs(signed)        # Distance to boundary

            if dist_to_boundary < min_dist:
                min_dist = dist_to_boundary
                min_signed = signed
                best_defect = defct
                best_dx = float(coord[0] - cx)
                best_dy = float(coord[1] - cy)

        dist_defect[idx] = min_dist
        signed_dist_defect[idx] = min_signed
        delta_x_def[idx] = best_dx
        delta_y_def[idx] = best_dy
        # Simulate defect_clusters format (compatible with downstream)
        closest_clusters[idx] = {
            'center': np.array([best_defect['cx'], best_defect['cy']]),
            'radius': best_defect['r']
        }

    # Build defect_clusters (simulate DBSCAN format for compatibility)
    defect_clusters = [
        {'center': np.array([d['cx'], d['cy']]), 'radius': d['r']}
        for d in defects
    ]

    # ---- 2. Calculate distance to load nodes ----
    load_node_ids = [nid for nid in load_dict.keys() if nid in nodes_dict]
    if load_node_ids:
        load_positions = np.array([nodes_dict[nid] for nid in load_node_ids])
    else:
        load_positions = np.array([]).reshape(0, 2)

    dist_load = {}
    all_coords = np.array([nodes_dict[pid] for pid in joint_map])
    x_min, x_max = all_coords[:, 0].min(), all_coords[:, 0].max()
    y_min, y_max = all_coords[:, 1].min(), all_coords[:, 1].max()

    if len(load_positions) > 0:
        for phys_id, idx in joint_map.items():
            coord = np.array(nodes_dict[phys_id])
            dists = np.linalg.norm(load_positions - coord, axis=1)
            dist_load[idx] = float(np.min(dists))
    else:
        diag = float(np.sqrt((x_max - x_min) ** 2 + (y_max - y_min) ** 2))
        diag = max(diag, 1.0)
        for idx in range(num_joints):
            dist_load[idx] = diag

    max_dist_defect = max(dist_defect.values()) if dist_defect else 1.0
    max_dist_load = max(dist_load.values()) if dist_load else 1.0

    return (dist_defect, dist_load,
            max(max_dist_defect, 1.0), max(max_dist_load, 1.0),
            defect_clusters, closest_clusters,
            delta_x_def, delta_y_def)  # New: explicitly return offsets


# ======================================================================
# Global normalization parameter calculation (adapted for enhanced features)
# ======================================================================
def compute_norm_params(raw_dir: str, inp_dir: str = None) -> dict:
    """
    扫描全部样本，统计归一化参数（适配增强特征版）。

    统计量：
      max_coord         : 节点坐标绝对值最大值
      max_length         : 撑杆长度最大值
      max_degree         : 铰接点度数最大值
      max_dist_defect    : 到缺陷边界的最大距离
      max_dist_load      : 到加载节点的最大距离
      max_defect_radius  : 缺陷半径最大值
    """
    # Prioritize discovering sample names from CSV，Fallback to INP directory
    jobs = set()
    if os.path.isdir(raw_dir):
        for f in os.listdir(raw_dir):
            if "_node_coords.csv" in f:
                jobs.add(f.replace("_node_coords.csv", ""))
    if inp_dir and os.path.isdir(inp_dir) and not jobs:
        for f in os.listdir(inp_dir):
            if f.endswith(".inp"):
                jobs.add(f.replace(".inp", ""))
    jobs = sorted(jobs)

    stats = {
        "max_coord": 0.0,
        "max_length": 0.0,
        "max_degree": 0,
        "max_dist_defect": 0.0,
        "max_dist_load": 0.0,
        "max_defect_radius": 0.0,
        "max_load_value": 0.0,
      }

    for job in tqdm(jobs, desc="扫描归一化参数"):
        # --- Parse nodes and elements ---
        nodes, edges_list = {}, []
        csv_node = os.path.join(raw_dir, f"{job}_node_coords.csv")
        csv_elem = os.path.join(raw_dir, f"{job}_element_connectivity.csv")

        if os.path.exists(csv_node) and os.path.exists(csv_elem):
            try:
                df_node = pd.read_csv(csv_node)
                nodes = {int(r['Node_Label']): [float(r['X']), float(r['Y'])]
                         for _, r in df_node.iterrows()}
                df_elem = pd.read_csv(csv_elem)
                edges_list = [(int(r['Element_Label']), int(r['Node1']), int(r['Node2']))
                              for _, r in df_elem.iterrows()]
            except Exception:
                continue
        elif inp_dir:
            inp_path = os.path.join(inp_dir, f"{job}.inp")
            if os.path.exists(inp_path):
                nodes, edges_list = parse_inp_nodes_and_elements(inp_path)

        if not nodes or not edges_list:
            continue

        # Coarsening
        struts, joint_map = group_elements_into_struts(nodes, edges_list)
        if not struts:
            continue

        # Statistics coordinates
        for nid, coords in nodes.items():
            if nid in joint_map:
                stats["max_coord"] = max(stats["max_coord"],
                                         abs(coords[0]), abs(coords[1]))

        # Statistics strut lengths
        for strut in struts:
            stats["max_length"] = max(stats["max_length"], strut['length'])

        # Statistics joint degrees
        degrees = defaultdict(int)
        for strut in struts:
            degrees[strut['u']] += 1
            degrees[strut['v']] += 1
        if degrees:
            stats["max_degree"] = max(stats["max_degree"], max(degrees.values()))

        # --- Parse boundary conditions and loads ---
        fixed_nodes = set()
        csv_bc = os.path.join(raw_dir, f"{job}_bc.csv")
        if os.path.exists(csv_bc):
            try:
                df_bc = pd.read_csv(csv_bc)
                fixed_nodes = set(int(v) for v in df_bc["Node_Label"])
            except Exception:
                pass
        elif inp_dir:
            inp_path = os.path.join(inp_dir, f"{job}.inp")
            if os.path.exists(inp_path):
                fixed_nodes = set(parse_inp_boundary_conditions(inp_path))

        load_dict = {}
        csv_load = os.path.join(raw_dir, f"{job}_load.csv")
        if os.path.exists(csv_load):
            try:
                df_load = pd.read_csv(csv_load)
                load_dict = dict(zip(df_load["Node_Label"], df_load["Load_Value"]))
            except Exception:
                pass
        elif inp_dir:
            inp_path = os.path.join(inp_dir, f"{job}.inp")
            if os.path.exists(inp_path):
                load_dict = parse_inp_loads(inp_path)

        # --- Statistics max_load_value ---
        if load_dict:
            stats["max_load_value"] = max(
                stats["max_load_value"],
                max(abs(float(v)) for v in load_dict.values())
            )

        # --- Statistics distance features + defect radius ---
        dist_defect, dist_load, sample_max_dd, sample_max_dl, defect_clusters, _, _, _ =\
            _compute_node_distances_dbscan(joint_map, nodes, fixed_nodes, load_dict, struts)
        stats["max_dist_defect"] = max(stats["max_dist_defect"], sample_max_dd)
        stats["max_dist_load"] = max(stats["max_dist_load"], sample_max_dl)
        # Extract maximum radius from defect cluster list
        if defect_clusters:
            sample_max_radius = max(cluster['radius'] for cluster in defect_clusters)
            stats["max_defect_radius"] = max(stats["max_defect_radius"], sample_max_radius)

        # --- Statistics stiffness degradation SDEG ---
        csv_sdeg = os.path.join(raw_dir, f"{job}_stiffness_degradation.csv")
        if os.path.exists(csv_sdeg):
            try:
                df_sdeg = pd.read_csv(csv_sdeg)
                if "Frame_Index" in df_sdeg.columns:
                    last_frame = df_sdeg["Frame_Index"].max()
                    df_sdeg = df_sdeg[df_sdeg["Frame_Index"] == last_frame]
            except Exception:
                pass

    # Lower bound protection
    stats["max_coord"] = max(stats["max_coord"], 1.0)
    stats["max_length"] = max(stats["max_length"], 1.0)
    stats["max_degree"] = max(stats["max_degree"], 1)
    stats["max_dist_defect"] = max(stats["max_dist_defect"], 1.0)
    stats["max_dist_load"] = max(stats["max_dist_load"], 1.0)
    stats["max_defect_radius"] = max(stats["max_defect_radius"], 1.0)
    stats["max_load_value"] = max(stats["max_load_value"], 1.0)

    return stats


def save_norm_params(params: dict, path: str):
    os.makedirs(os.path.dirname(path) if os.path.dirname(path) else ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(params, f, indent=2, ensure_ascii=False)
    print(f"归一化参数已保存至: {path}")


def load_norm_params(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        params = json.load(f)
    # Compatible with legacy parameter files
    if "max_dist_defect" not in params:
        params["max_dist_defect"] = params.get("max_coord", 100.0)
    if "max_dist_load" not in params:
        params["max_dist_load"] = params.get("max_coord", 100.0)
    if "max_defect_radius" not in params:
        params["max_defect_radius"] = params.get("max_coord", 100.0)
    if "max_load_value" not in params:
        params["max_load_value"] = 1.0
    return params


# ======================================================================
# Step 3: Strut-dual-circle precise geometric features
# ======================================================================
def _strut_circle_intersection(strut_p, strut_q, cx, cy, r):
    """
    计算线段 PQ 与圆(cx, cy, r)的交互。

    返回：
        intersect      : float  1.0=相交，0.0=不相交
        frac_in_circle : float  杆在圆内长度占比 [0, 1]
        dist_to_boundary_u : float  u端到圆边界的距离（最近）
        dist_to_boundary_v : float  v端到圆边界的距离（最近）
    """
    p = np.array(strut_p, dtype=np.float64)
    q = np.array(strut_q, dtype=np.float64)
    c = np.array([cx, cy], dtype=np.float64)

    # Direction vector and parameterization
    d = q - p
    f = p - c
    a = float(np.dot(d, d))
    b = 2.0 * float(np.dot(f, d))
    c_val = float(np.dot(f, f)) - r * r
    discriminant = b * b - 4.0 * a * c_val

    u_to_c = float(np.linalg.norm(p - c))
    v_to_c = float(np.linalg.norm(q - c))
    dist_u = abs(u_to_c - r)
    dist_v = abs(v_to_c - r)

    if discriminant < 0:
        # No intersection
        if u_to_c < r and v_to_c < r:
            # Entire strut inside circle
            return 1.0, 1.0, dist_u, dist_v
        return 0.0, 0.0, dist_u, dist_v

    sqrt_disc = np.sqrt(discriminant)
    t1 = (-b - sqrt_disc) / (2.0 * a)
    t2 = (-b + sqrt_disc) / (2.0 * a)

    if (t1 >= 0 and t1 <= 1) or (t2 >= 0 and t2 <= 1) or (t1 < 0 and t2 > 1):
        # Intersection
        t_enter = max(0.0, t1)
        t_exit = min(1.0, t2)
        frac = max(0.0, t_exit - t_enter)
        # Also check case where both ends are inside circle
        if u_to_c <= r and v_to_c <= r:
            frac = 1.0
        return 1.0, frac, dist_u, dist_v

    # No intersection but both ends inside circle
    if u_to_c < r and v_to_c < r:
        return 1.0, 1.0, dist_u, dist_v

    return 0.0, 0.0, dist_u, dist_v


def _compute_dual_circle_edge_features(strut, defects, max_length):
    """
    计算一根撑杆相对两个圆孔缺陷的精确几何特征。

    参数：
        strut      : dict  撑杆 {u, v, vec, elem_ids, length}
        defects    : list  [{cx, cy, r}, ...] 按 cx 排序
        max_length : float  全局最大杆长（归一化用）

    返回：
        feat : np.ndarray (20,)  双圆特征向量
    """
    # Strut endpoint coordinates
    u_coord = strut['u']
    v_coord = strut['v']
    strut_mid = ((u_coord[0] + v_coord[0]) / 2.0, (u_coord[1] + v_coord[1]) / 2.0)
    strut_vec = strut['vec']

    n_defects = len(defects)
    feat = np.zeros(n_defects * 9 + 2, dtype=np.float32)  # 9 per defect + 2 coupling

    for di, defct in enumerate(defects):
        cx, cy, r = defct['cx'], defct['cy'], defct['r']
        base = di * 9

        # 1. Distance from strut midpoint to circle center (normalized)
        mid_np = np.array(strut_mid, dtype=np.float64)
        dist_to_center = float(np.linalg.norm(mid_np - np.array([cx, cy])))
        feat[base + 0] = dist_to_center / max_length

        # 2. Signed distance (negative = inside circle)，Normalized by defect radius
        signed_dist = dist_to_center - r
        feat[base + 1] = signed_dist / max(r, 1e-6)

        # 3-4. Distance from endpoints to circle boundary (normalized)，Normalized by defect radius
        u_np = np.array(u_coord, dtype=np.float64)
        v_np = np.array(v_coord, dtype=np.float64)
        du = float(np.linalg.norm(u_np - np.array([cx, cy]))) - r
        dv = float(np.linalg.norm(v_np - np.array([cx, cy]))) - r
        feat[base + 2] = du / max(r, 1e-6)
        feat[base + 3] = dv / max(r, 1e-6)

        # 5. Whether intersects
        inter, frac, du_b, dv_b = _strut_circle_intersection(
            u_coord, v_coord, cx, cy, r)
        feat[base + 4] = inter

        # 6. Length fraction inside circle
        feat[base + 5] = frac

        # 7. Cosine of angle between strut and center-to-midpoint (radial alignment)
        center_to_mid = mid_np - np.array([cx, cy])
        center_to_mid_norm = float(np.linalg.norm(center_to_mid))
        if center_to_mid_norm > 1e-8:
            strut_dir = np.array(strut_vec, dtype=np.float64)
            strut_norm = float(np.linalg.norm(strut_dir))
            if strut_norm > 1e-8:
                strut_dir /= strut_norm
                cos_angle = float(np.dot(strut_dir, center_to_mid / center_to_mid_norm))
            else:
                cos_angle = 0.0
        else:
            cos_angle = 0.0
        feat[base + 6] = cos_angle

        # 8. min(distance from both ends to boundary)（Normalized by defect radius）
        feat[base + 7] = min(du_b, dv_b) / max(r, 1e-6)

        # 9. max(distance from both ends to boundary)（Normalized by defect radius）
        feat[base + 8] = max(du_b, dv_b) / max(r, 1e-6)

    # === Dual-defect coupling terms ===
    if n_defects >= 2:
        d1, d2 = defects[0], defects[1]
        c1 = np.array([d1['cx'], d1['cy']])
        c2 = np.array([d2['cx'], d2['cy']])
        mid_np = np.array(strut_mid, dtype=np.float64)

        # dist1 - dist2 (which defect is closer)
        dist1 = float(np.linalg.norm(mid_np - c1))
        dist2 = float(np.linalg.norm(mid_np - c2))
        feat[-2] = (dist1 - dist2) / max_length  # negative = closer to right defect

        # Perpendicular distance to ligament (line between two circles)
        ligament_vec = c2 - c1
        ligament_norm = float(np.linalg.norm(ligament_vec))
        if ligament_norm > 1e-8:
            mid_to_c1 = mid_np - c1
            proj_len = float(np.dot(mid_to_c1, ligament_vec / ligament_norm))
            proj_pt = c1 + ligament_vec / ligament_norm * proj_len
            dist_to_lig = float(np.linalg.norm(mid_np - proj_pt))
        else:
            dist_to_lig = 0.0
        feat[-1] = dist_to_lig / max_length

    return feat


def _compute_defect_frame_edge_features(strut, defects, max_coord):
    """
    Defect-local edge features for the fixed-template setting.

    The truss topology is the same for every sample, so raw x/y and topology are
    mostly shared. These features express each strut in the local frame of each
    defect and normalize distance by the defect radius, which is the part that
    changes from sample to sample.
    """
    u_coord = np.asarray(strut['u'], dtype=np.float64)
    v_coord = np.asarray(strut['v'], dtype=np.float64)
    mid = (u_coord + v_coord) * 0.5
    vec = np.asarray(strut['vec'], dtype=np.float64)
    vec_norm = float(np.linalg.norm(vec))
    edge_dir = vec / vec_norm if vec_norm > 1e-8 else np.zeros(2, dtype=np.float64)

    feat = np.zeros(14, dtype=np.float32)
    for di, defct in enumerate(defects[:2]):
        base = di * 6
        center = np.asarray([defct['cx'], defct['cy']], dtype=np.float64)
        radius = max(float(defct['r']), 1e-6)
        rel_mid = mid - center
        dist_mid = float(np.linalg.norm(rel_mid))
        signed_by_radius = (dist_mid - radius) / radius
        feat[base + 0] = float(np.clip(signed_by_radius, -3.0, 3.0)) / 3.0
        feat[base + 1] = float(np.clip(abs(signed_by_radius), 0.0, 3.0)) / 3.0

        du_signed = (float(np.linalg.norm(u_coord - center)) - radius) / radius
        dv_signed = (float(np.linalg.norm(v_coord - center)) - radius) / radius
        feat[base + 2] = 1.0 if du_signed * dv_signed <= 0.0 else 0.0
        feat[base + 3] = float(np.clip(min(abs(du_signed), abs(dv_signed)), 0.0, 3.0)) / 3.0

        if dist_mid > 1e-8 and vec_norm > 1e-8:
            radial = rel_mid / dist_mid
            tangent = np.array([-radial[1], radial[0]], dtype=np.float64)
            feat[base + 4] = abs(float(np.dot(edge_dir, radial)))
            feat[base + 5] = abs(float(np.dot(edge_dir, tangent)))

    if len(defects) >= 2:
        c1 = np.asarray([defects[0]['cx'], defects[0]['cy']], dtype=np.float64)
        c2 = np.asarray([defects[1]['cx'], defects[1]['cy']], dtype=np.float64)
        r1 = max(float(defects[0]['r']), 1e-6)
        r2 = max(float(defects[1]['r']), 1e-6)
        lig_vec = c2 - c1
        lig_len = float(np.linalg.norm(lig_vec))
        if lig_len > 1e-8:
            lig_unit = lig_vec / lig_len
            proj = float(np.dot(mid - c1, lig_unit))
            feat[12] = min(max(proj / lig_len, 0.0), 1.0)
            corridor_gap = max(lig_len - r1 - r2, 1e-6)
            closest = c1 + lig_unit * proj
            feat[13] = float(np.clip(np.linalg.norm(mid - closest) / corridor_gap, 0.0, 3.0)) / 3.0
    else:
        feat[12] = 0.5
        feat[13] = 1.0

    return feat


# ======================================================================
# Single sample processing: build coarsened strut graph (geometry-only features)
# ======================================================================
def process_single_simulation(
    nodes_dict, edges_list, fixed_nodes, load_dict,
    elem_status_last_frame,
    norm_params
):
    """
    将单个桁架仿真转换为 PyG 图数据（纯几何特征）

    节点特征（11 维）：
      0  x_norm              归一化 X 坐标
      1  y_norm              归一化 Y 坐标
      2  degree_norm         归一化度数
      3  dist_to_defect_norm 归一化到最近缺陷边界距离
      4  dist_to_load_norm   归一化到最近加载节点的距离
      5  delta_x_def         到最近缺陷中心的相对位移 X（归一化）
      6  delta_y_def         到最近缺陷中心的相对位移 Y（归一化）
      7  defect_radius_norm  归一化缺陷半径
      8  proximity_index     邻近指数
      9  topo_dist_to_fixed  到固定端的拓扑跳数距离
     10  topo_dist_to_load   到加载端的拓扑跳数距离

    边特征（39 维 = 基础 1D + 方向 4D + 双圆 20D + 缺陷局部坐标 14D）：
      0   length_norm            归一化撑杆长度
      1-4 dir_4d                 方向 one-hot：水平/竖直/正斜/负斜
      5-13 缺陷1 9项：dist_center/signed_dist/du/dv/intersect/frac_in/cos_angle/min_d/max_d
     14-22 缺陷2 9项：同上
     23-24 耦合 2项：dist1_minus_dist2 / dist_to_ligament
     25-38 缺陷局部坐标 14项：
           每个缺陷 6项：signed_dist/r, abs_dist/r, crosses_boundary,
           min_endpoint_dist/r, radial_align, tangent_align
           双缺陷 2项：ligament projection / ligament corridor distance
    """
    # 1. Mesh coarsening
    struts, joint_map = group_elements_into_struts(nodes_dict, edges_list)
    if not struts:
        return None

    num_joints = len(joint_map)
    num_struts = len(struts)

    # ==== NEW Step 1: Fixed template reconstruction + missing edge identification ====
    template_nodes, template_edges, grid_nx, grid_ny, phys_to_gi = build_mesh_template(nodes_dict)
    sample_edges = extract_sample_mesh_edges(nodes_dict, edges_list)
    missing_edges = find_missing_template_edges(template_nodes, template_edges, sample_edges, nodes_dict)

    # ==== NEW Step 2: Dual-circle fitting ====
    defects = fit_dual_circles(missing_edges)

    # 2. Joint degrees
    joint_degrees = defaultdict(int)
    for strut in struts:
        joint_degrees[strut['u']] += 1
        joint_degrees[strut['v']] += 1

    # 3. Build topology graph and calculate topological features
    G = nx.Graph()
    for strut in struts:
        G.add_edge(strut['u'], strut['v'])
    topo_dist_to_fixed, topo_dist_to_load = compute_topology_features(G, joint_map, fixed_nodes, load_dict)

    # 4. Calculate distance + defect cluster info (based on dual-circle params)
    (dist_defect, dist_load, _, _,
     defect_clusters, closest_clusters,
     delta_x_def, delta_y_def) = _compute_node_distances(
        joint_map, nodes_dict, fixed_nodes, load_dict,
        defects=defects
    )

    # 5. Strut type classification
    strut_dirs = _classify_strut_directions(struts, joint_map, nodes_dict)

    # 6. Normalization parameters
    max_coord = norm_params["max_coord"]
    max_degree = norm_params["max_degree"]
    max_dist_defect = norm_params["max_dist_defect"]
    max_dist_load = norm_params["max_dist_load"]
    max_defect_radius = norm_params.get("max_defect_radius", max_coord)
    max_length = norm_params["max_length"]
    max_load_value = norm_params.get("max_load_value", 1.0)

    # Convert physical IDs to joint_map indices
    fixed_indices = set(joint_map[n] for n in fixed_nodes if n in joint_map)
    load_indices = set(joint_map[n] for n in load_dict.keys() if n in joint_map)
    load_values_idx = {joint_map[n]: v for n, v in load_dict.items() if n in joint_map}

    # Calculate sample-level load_value_norm
    sample_load_abs = max([abs(float(v)) for v in load_dict.values()], default=0.0)
    sample_load_norm = sample_load_abs / max_load_value if max_load_value > 0 else 0.0

    # 7. node features [num_joints, 14]
    x = torch.zeros((num_joints, 14), dtype=torch.float32)

    for phys_id, idx in joint_map.items():
        coords = nodes_dict[phys_id]
        d = dist_defect.get(idx, 0.0)
        cluster = closest_clusters.get(idx, defect_clusters[0])
        defect_center = cluster['center']
        defect_radius = cluster['radius']
        defect_radius_norm = defect_radius / max_defect_radius

        x[idx, 0] = coords[0] / max_coord                       # x_norm
        x[idx, 1] = coords[1] / max_coord                       # y_norm
        x[idx, 2] = joint_degrees.get(idx, 0) / max_degree      # degree_norm
        x[idx, 3] = d / max_dist_defect                         # dist_to_defect_norm
        x[idx, 4] = dist_load.get(idx, 0.0) / max_dist_load     # dist_to_load_norm
        x[idx, 5] = (coords[0] - defect_center[0]) / max_coord  # delta_x_def
        x[idx, 6] = (coords[1] - defect_center[1]) / max_coord  # delta_y_def
        x[idx, 7] = defect_radius_norm                          # defect_radius_norm
        x[idx, 8] = min(defect_radius / (d + PROXIMITY_EPS), PROXIMITY_CLIP) / PROXIMITY_CLIP  # proximity_index
        x[idx, 9] = min(topo_dist_to_fixed.get(idx, TOPO_DIST_DEFAULT) / TOPO_DIST_MAX_HOPS, 1.0)
        x[idx, 10] = min(topo_dist_to_load.get(idx, TOPO_DIST_DEFAULT) / TOPO_DIST_MAX_HOPS, 1.0)
        x[idx, 11] = 1.0 if idx in fixed_indices else 0.0       # is_fixed
        x[idx, 12] = 1.0 if idx in load_indices else 0.0       # is_load_node
        x[idx, 13] = sample_load_norm                          # load_value_norm (sample-level)

    # 7. Calculate label y (critical_ratio from last STATUS frame)

    # 8. Edge feature construction (select combinations based on feature groups)
    # Feature groups：
    # A: Use only 0:5 (length + direction) - 5D
    # B: Use 0:5 + 5:25 (length + direction + dual-circle) - 25D
    # C: Use 0:5 + 25:39 (length + direction + defect) - 19D
    # D: All 0:39 (all features) - 39D
    feature_group = os.environ.get('FEATURE_GROUP', 'D')
    
    if feature_group == 'A':
        edge_dim = 5
    elif feature_group == 'B':
        edge_dim = 25
    elif feature_group == 'C':
        edge_dim = 19
    else:  # D
        edge_dim = 41
    
    edge_index = torch.zeros((2, num_struts * 2), dtype=torch.long)
    edge_attr = torch.zeros((num_struts * 2, edge_dim), dtype=torch.float32)

    # Label: final fracture (calculated from last STATUS frame)
    y = torch.zeros(num_struts, dtype=torch.float32)

    idx_to_phys = {v: k for k, v in joint_map.items()}

    for i, strut in enumerate(struts):
        # Label: any element fracture means strut fracture
        elem_ids = strut['elem_ids']
        
        if not elem_ids:
            y[i] = 1.0  # defaultintact
            continue
        
        status_values = [elem_status_last_frame.get(elem_id, 1.0) for elem_id in elem_ids]
        
        # y=0 means fracture，y=1 means intact；Abaqus STATUS=0 usually means failed/deleted
        y[i] = 1.0 if any(status_value < 0.5 for status_value in status_values) else 0.0

        # Basic features 1D
        length_norm = strut['length'] / max_length

        # Dual-circle geometric features (20D)
        strut_phys_coords = (
            nodes_dict[idx_to_phys[strut['u']]],
            nodes_dict[idx_to_phys[strut['v']]],
        )
        strut_with_coords = {
            'u': strut_phys_coords[0],
            'v': strut_phys_coords[1],
            'vec': strut['vec'],
            'length': strut['length'],
        }
        dual_feat = _compute_dual_circle_edge_features(strut_with_coords, defects, max_length)

        # Defect local coordinate features (14D)
        defect_frame_feat = _compute_defect_frame_edge_features(strut_with_coords, defects, max_coord)

        # Forward edge u → v
        edge_index[0, i] = strut['u']
        edge_index[1, i] = strut['v']
        
        # Length features
        edge_attr[i, 0] = length_norm
        # Direction features
        edge_attr[i, 1:5] = torch.tensor(strut_dirs[i], dtype=torch.float32)          # 4D one-hot direction
        
        # Add other features based on feature groups
        if feature_group in ['B', 'D']:
            # Dual-circle features
            edge_attr[i, 5:25] = torch.tensor(dual_feat, dtype=torch.float32)             # 20D dual-circle features
        if feature_group in ['C', 'D']:
            # Defect local coordinate features
            start_idx = 5 if feature_group == 'C' else 25
            if feature_group == 'D':
                edge_attr[i, 25:39] = torch.tensor(defect_frame_feat, dtype=torch.float32)  # 14D defect local coordinate features (don't overwrite vec_x/vec_y)
            else:
                edge_attr[i, start_idx:] = torch.tensor(defect_frame_feat, dtype=torch.float32)
        if feature_group == 'D':
            # vec_x, vec_y (true direction vector)
            edge_attr[i, 39] = strut['vec'][0]
            edge_attr[i, 40] = strut['vec'][1]

        # Reverse edge v → u
        edge_index[0, i + num_struts] = strut['v']
        edge_index[1, i + num_struts] = strut['u']
        edge_attr[i + num_struts, 0] = length_norm
        edge_attr[i + num_struts, 1:5] = torch.tensor(strut_dirs[i], dtype=torch.float32)  # Direction unchanged

        if feature_group in ['B', 'D']:
            edge_attr[i + num_struts, 5:25] = torch.tensor(dual_feat, dtype=torch.float32)             # Dual-circle features unchanged
        if feature_group in ['C', 'D']:
            start_idx = 5 if feature_group == 'C' else 25
            if feature_group == 'D':
                edge_attr[i + num_struts, 25:39] = torch.tensor(defect_frame_feat, dtype=torch.float32)  # Don't overwrite vec_x/vec_y
            else:
                edge_attr[i + num_struts, start_idx:] = torch.tensor(defect_frame_feat, dtype=torch.float32)
        if feature_group == 'D':
            # vec_x, vec_y (negated for reverse edge)
            edge_attr[i + num_struts, 39] = -strut['vec'][0]
            edge_attr[i + num_struts, 40] = -strut['vec'][1]

    # edge_mask: forward edges only
    edge_mask = torch.zeros(num_struts * 2, dtype=torch.bool)
    edge_mask[:num_struts] = True

    return Data(
        x=x, edge_index=edge_index, edge_attr=edge_attr,
        y=y, edge_mask=edge_mask
    )


# ======================================================================
# Multiprocessing preprocessing worker (top-level function, must be defined outside import section)
# ======================================================================
def _process_job_worker(args):
    """
    多进程 worker：处理单个 job 的全流程。
    返回 (job, graph_data_dict) 或 (job, None) 表示失败。
    使用 per-job .pt 缓存，加速重复运行。
    """
    job, cache_dir, norm_params = args
    os.makedirs(cache_dir, exist_ok=True)
    cache_path = os.path.join(cache_dir, f"{job}.pt")
    norm_key = _norm_cache_key(norm_params)

    # ---- Skip if cache exists (supports resume)----
    if os.path.exists(cache_path):
        try:
            cached = torch.load(cache_path)
            if cached.get("cache_version") == DATA_CACHE_VERSION and cached.get("norm_key") == norm_key:
                return job, cache_path
        except Exception:
            pass

    # ---- 1. Load raw data (prefer CSV, fallback to INP)----
    nodes, edges_list = {}, []
    csv_node = os.path.join(RAW_DATA_DIR, f"{job}_node_coords.csv")
    csv_elem = os.path.join(RAW_DATA_DIR, f"{job}_element_connectivity.csv")
    try:
        if os.path.exists(csv_node) and os.path.exists(csv_elem):
            df_node = pd.read_csv(csv_node, low_memory=False)
            nodes = {int(r["Node_Label"]): [float(r["X"]), float(r["Y"])]
                     for _, r in df_node.iterrows()}
            df_elem = pd.read_csv(csv_elem, low_memory=False)
            edges_list = [(int(r["Element_Label"]), int(r["Node1"]), int(r["Node2"]))
                          for _, r in df_elem.iterrows()]
        else:
            # Read from INP file
            inp_path = os.path.join(INP_DATA_DIR, f"{job}.inp")
            if os.path.exists(inp_path):
                nodes, edges_list = parse_inp_nodes_and_elements(inp_path)
            else:
                return job, None
    except (MemoryError, OSError, ValueError) as e:
        return job, None

    if not nodes or not edges_list:
        return job, None

    # Fixed nodes (prefer CSV, fallback to INP)
    fixed_nodes = set()
    csv_bc = os.path.join(RAW_DATA_DIR, f"{job}_bc.csv")
    if os.path.exists(csv_bc):
        try:
            df_bc = pd.read_csv(csv_bc)
            fixed_nodes = set(int(v) for v in df_bc["Node_Label"])
        except Exception:
            pass
    else:
        inp_path = os.path.join(INP_DATA_DIR, f"{job}.inp")
        if os.path.exists(inp_path):
            fixed_nodes = set(parse_inp_boundary_conditions(inp_path))

    # Loads (prefer CSV, fallback to INP)
    load_dict = {}
    csv_load = os.path.join(RAW_DATA_DIR, f"{job}_load.csv")
    if os.path.exists(csv_load):
        try:
            df_load = pd.read_csv(csv_load)
            load_dict = dict(zip(df_load["Node_Label"], df_load["Load_Value"]))
        except Exception:
            pass
    else:
        inp_path = os.path.join(INP_DATA_DIR, f"{job}.inp")
        if os.path.exists(inp_path):
            load_dict = parse_inp_loads(inp_path)

    # Last frame STATUS (compatible with no Frame_Index)
    elem_status_last_frame = {}
    csv_status = os.path.join(RAW_DATA_DIR, f"{job}_status.csv")
    if os.path.exists(csv_status):
        try:
            df_status = pd.read_csv(csv_status)

            if "Frame_Index" in df_status.columns:
                last_frame = df_status["Frame_Index"].max()
                df_last = df_status[df_status["Frame_Index"] == last_frame]
            else:
                df_last = df_status

            pivot = df_last.pivot_table(
                index="Element_Label", values="STATUS", aggfunc="mean")
            elem_status_last_frame = {
                int(eid): float(pivot.loc[eid].values[0])
                for eid in pivot.index
            }
        except Exception as e:
            print(f"[WARN] failed to read status for {job}: {e}")

    # ---- 2. Full pipeline processing (exception-safe)----
    try:
        data = process_single_simulation(
            nodes, edges_list, fixed_nodes, load_dict,
            elem_status_last_frame, norm_params
        )
    except Exception:
        return job, None
    if data is None:
        return job, None

    # ---- 3. Cache as .pt ----
    torch.save({
        "cache_version": DATA_CACHE_VERSION,
        "norm_key": norm_key,
        "x": data.x.cpu(),
        "edge_index": data.edge_index.cpu(),
        "edge_attr": data.edge_attr.cpu(),
        "y": data.y.cpu(),
        "edge_mask": data.edge_mask.cpu(),
    }, cache_path)
    return job, cache_path


def _load_cached_sample(cache_path):
    """从 .pt 缓存加载单个样本的 Data 对象。"""
    arrs = torch.load(cache_path)
    return Data(
        x=arrs["x"],
        edge_index=arrs["edge_index"],
        edge_attr=arrs["edge_attr"],
        y=arrs["y"],
        edge_mask=arrs["edge_mask"],
    )


# ======================================================================
# Feature group definitions
# ======================================================================
NODE_FEATURE_GROUPS = {
    'Nall': (0, 14),  # All 14D
    'N0': (0, 2),     # Coordinates x,y
    'N1': (0, 5),     # Coordinates + degree + dist_to_defect + dist_to_load
    'N2': ([0, 1, 2, 3, 4, 9, 10], None),  # Basic + topological distance
    'N3': ([0, 1, 2, 3, 4, 5, 6, 7, 8], None),  # Basic + defect local info
    'N4': (0, 14),    # Same as Nall
    'Nlite': ([0, 1, 11, 12, 13, 2], None),  # x, y, is_fixed, is_load_node, load_value_norm, degree
}

EDGE_FEATURE_GROUPS = {
    'Eall': (0, 41),  # All 41D
    'E0': (0, 1),    # Length only
    'E1': (0, 5),    # Length + direction one-hot
    'E2': ([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24], None),  # Basic + dual-circle
    'E3': ([0, 1, 2, 3, 4, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38], None),  # Basic + defect frame
    'E4': (0, 41),    # Same as Eall
    'E1vec': ([0, 39, 40], None),  # length + vec_x + vec_y (true vector)
    'Elite': ([0, 39, 40], None),  # length, vec_x, vec_y
}


def select_node_features(x, node_group):
    """根据节点特征组选择特征"""
    if node_group == 'Nall' or node_group == 'N4':
        return x
    elif node_group == 'N0':
        return x[:, 0:2]
    elif node_group == 'N1':
        return x[:, 0:5]
    elif node_group == 'N2':
        indices = [0, 1, 2, 3, 4, 9, 10]
        return x[:, indices]
    elif node_group == 'N3':
        indices = [0, 1, 2, 3, 4, 5, 6, 7, 8]
        return x[:, indices]
    elif node_group == 'Nlite':
        indices = [0, 1, 11, 12, 13, 2]
        return x[:, indices]
    else:
        return x


def select_edge_features(edge_attr, edge_group):
    """根据边特征组选择特征"""
    if edge_group == 'Eall' or edge_group == 'E4':
        return edge_attr
    elif edge_group == 'E0':
        return edge_attr[:, 0:1]
    elif edge_group == 'E1':
        return edge_attr[:, 0:5]
    elif edge_group == 'E2':
        indices = list(range(0, 25))
        return edge_attr[:, indices]
    elif edge_group == 'E3':
        indices = [0, 1, 2, 3, 4] + list(range(25, 39))
        return edge_attr[:, indices]
    elif edge_group == 'E1vec' or edge_group == 'Elite':
        # Handle both cases:
        # 1. Old design: edge_attr has 41D, columns 39/40 are vec_x/vec_y
        # 2. New data: edge_attr has only 39D, need to compute vec_x/vec_y from direction one-hot
        if edge_attr.size(1) >= 41:
            return edge_attr[:, [0, 39, 40]]
        
        if edge_attr.size(1) >= 5:
            length = edge_attr[:, 0:1]
            
            # Assume edge_attr[:, 1:5] is direction one-hot:
            # horizontal, vertical, positive diagonal, negative diagonal
            vec_x = (
                edge_attr[:, 1] * 1.0 +
                edge_attr[:, 2] * 0.0 +
                edge_attr[:, 3] * 0.70710678 +
                edge_attr[:, 4] * 0.70710678
            ).unsqueeze(1)
            
            vec_y = (
                edge_attr[:, 1] * 0.0 +
                edge_attr[:, 2] * 1.0 +
                edge_attr[:, 3] * 0.70710678 -
                edge_attr[:, 4] * 0.70710678
            ).unsqueeze(1)
            
            return torch.cat([length, vec_x, vec_y], dim=1)
        
        raise ValueError(
            f"Elite/E1vec requires at least 5 edge features, got {edge_attr.size(1)}"
        )
    else:
        return edge_attr


# ======================================================================
# Dataset class
# ======================================================================
class TrussStrutDataset(InMemoryDataset):
    """桁架撑杆断裂预测数据集（边级预测 · 网格粗化 · 纯几何特征）。"""

    def __init__(self, root, norm_params=None, inp_dir=None, 
                 node_feature_group='Nall', edge_feature_group='Eall',
                 transform=None, pre_transform=None):
        self.norm_params = norm_params
        self.inp_dir = inp_dir
        self.node_feature_group = node_feature_group
        self.edge_feature_group = edge_feature_group
        super().__init__(root, transform, pre_transform)
        print(f"[DATASET] loading processed graph file: {self.processed_paths[0]}")
        self.data, self.slices = torch.load(self.processed_paths[0], weights_only=False)
        
        self._apply_feature_selection()
        if self.len() > 0:
            sample = self.get(0)
            print(
                f"[DATASET] loaded | graphs={self.len()} node_features={self.node_feature_group}:{sample.x.size(1)} "
                f"edge_features={self.edge_feature_group}:{sample.edge_attr.size(1)}"
            )
    
    def _apply_feature_selection(self):
        """应用特征组选择"""
        if self.node_feature_group != 'Nall' and self.node_feature_group != 'N4':
            self.data.x = select_node_features(self.data.x, self.node_feature_group)
        
        if self.edge_feature_group != 'Eall' and self.edge_feature_group != 'E4':
            self.data.edge_attr = select_edge_features(self.data.edge_attr, self.edge_feature_group)

    @property
    def raw_file_names(self):
        return []

    @property
    def processed_file_names(self):
        return [f"truss_strut_graph_data_v{DATA_CACHE_VERSION}.pt"]

    def _load_sample_data(self, job):
        """
        加载单个样本的全部数据。

        返回：
            nodes, edges_list, fixed_nodes, load_dict,
            elem_status_last_frame, elem_sdeg_allframes, frames
        """
        # --- Nodes and elements ---
        nodes, edges_list = {}, []
        csv_node = os.path.join(RAW_DATA_DIR, f"{job}_node_coords.csv")
        csv_elem = os.path.join(RAW_DATA_DIR, f"{job}_element_connectivity.csv")

        if os.path.exists(csv_node) and os.path.exists(csv_elem):
            df_node = pd.read_csv(csv_node)
            nodes = {int(r['Node_Label']): [float(r['X']), float(r['Y'])]
                     for _, r in df_node.iterrows()}
            df_elem = pd.read_csv(csv_elem)
            edges_list = [(int(r['Element_Label']), int(r['Node1']), int(r['Node2']))
                          for _, r in df_elem.iterrows()]
        else:
            inp_path = os.path.join(self.inp_dir or INP_DATA_DIR, f"{job}.inp")
            if os.path.exists(inp_path):
                nodes, edges_list = parse_inp_nodes_and_elements(inp_path)

        if not nodes or not edges_list:
            return None

        # --- fixed node ---
        fixed_nodes = set()
        csv_bc = os.path.join(RAW_DATA_DIR, f"{job}_bc.csv")
        if os.path.exists(csv_bc):
            try:
                df_bc = pd.read_csv(csv_bc)
                fixed_nodes = set(int(v) for v in df_bc["Node_Label"])
            except Exception:
                pass
        else:
            inp_path = os.path.join(self.inp_dir or INP_DATA_DIR, f"{job}.inp")
            if os.path.exists(inp_path):
                fixed_nodes = set(parse_inp_boundary_conditions(inp_path))

        # --- load ---
        load_dict = {}
        csv_load = os.path.join(RAW_DATA_DIR, f"{job}_load.csv")
        if os.path.exists(csv_load):
            try:
                df_load = pd.read_csv(csv_load)
                load_dict = dict(zip(df_load["Node_Label"], df_load["Load_Value"]))
            except Exception:
                pass
        else:
            inp_path = os.path.join(self.inp_dir or INP_DATA_DIR, f"{job}.inp")
            if os.path.exists(inp_path):
                load_dict = parse_inp_loads(inp_path)

        # --- Fracture status (last frame only, vectorized)---
        # Compatible with no Frame_Index
        elem_status_last_frame = {}
        csv_status = os.path.join(RAW_DATA_DIR, f"{job}_status.csv")
        
        if os.path.exists(csv_status):
            try:
                df_status = pd.read_csv(csv_status)

                if "Frame_Index" in df_status.columns:
                    last_frame = df_status["Frame_Index"].max()
                    frames = [last_frame]
                    df_last = df_status[df_status["Frame_Index"] == last_frame]
                else:
                    frames = []
                    df_last = df_status

                pivot = df_last.pivot_table(
                    index="Element_Label",
                    values="STATUS",
                    aggfunc="mean"
                )

                elem_status_last_frame = {
                    int(eid): float(pivot.loc[eid].values[0])
                    for eid in pivot.index
                }

            except Exception as e:
                print(f"[WARN] failed to read status for {job}: {e}")

        # SDEG data no longer needed (temporal features removed)
        elem_sdeg_allframes = {}

        return nodes, edges_list, fixed_nodes, load_dict, elem_status_last_frame, elem_sdeg_allframes, frames

    def process(self):
        import multiprocessing as mp

        if self.norm_params is None:
            print("[警告] 未提供 norm_params，使用默认值。建议先调用 compute_norm_params()。")
            self.norm_params = {
                "max_coord": 100.0,
                "max_length": 100.0,
                "max_degree": 8,
                "max_dist_defect": 100.0,
                "max_dist_load": 100.0,
                "max_defect_radius": 100.0,
            }
        if "max_dist_defect" not in self.norm_params:
            self.norm_params["max_dist_defect"] = self.norm_params.get("max_coord", 100.0)
        if "max_dist_load" not in self.norm_params:
            self.norm_params["max_dist_load"] = self.norm_params.get("max_coord", 100.0)
        if "max_defect_radius" not in self.norm_params:
            self.norm_params["max_defect_radius"] = self.norm_params.get("max_coord", 100.0)

        # Discover samples (based on INP files)
        jobs = set()
        
        inp_dir = self.inp_dir or INP_DATA_DIR
        if inp_dir and os.path.isdir(inp_dir):
            for f in os.listdir(inp_dir):
                if f.endswith(".inp"):
                    jobs.add(f.replace(".inp", ""))
        
        jobs = sorted(jobs)
        print(f"[DATASET BUILD] discovered {len(jobs)} jobs from RAW_DATA_DIR={RAW_DATA_DIR} and INP_DATA_DIR={inp_dir}")

        # Per-job cache directory
        cache_dir = os.path.join(self.root, "_sample_cache")
        os.makedirs(cache_dir, exist_ok=True)

        # Statistics
        stats_counts = {"total": 0, "success": 0, "skip": 0, "cache_hit": 0}

        # ---- Multiprocessing parallel processing (limit processes by available memory)----
        # Memory limit: max 1 process，Avoid OOM
        import psutil
        avail_gb = psutil.virtual_memory().available / 1024**3
        num_workers = 16  # 112-core CPU supports more parallel processes（Windows multiprocessing overhead is heavy）
        print(f"[优化] 可用 RAM={avail_gb:.1f}GB，使用 {num_workers} 个进程并行处理 {len(jobs)} 个样本...")

        worker_args = [(job, cache_dir, self.norm_params) for job in jobs]
        data_list = []
        cache_hit_data = []

        with mp.Pool(processes=num_workers) as pool:
            results_iter = pool.imap_unordered(_process_job_worker, worker_args, chunksize=1)
            # Wrap with tqdm for real-time progress
            pbar = tqdm(results_iter, total=len(jobs), desc="处理样本", mininterval=1.0)
            for job, result in pbar:
                stats_counts["total"] += 1
                pbar.set_postfix_str(
                    f"成功={stats_counts['success']} 跳过={stats_counts['skip']}",
                    refresh=True
                )
                if result is None:
                    stats_counts["skip"] += 1
                    continue

                # Load from .pt cache (IO faster than rebuilding)
                try:
                    data = _load_cached_sample(result)
                    cache_hit_data.append(data)
                    stats_counts["cache_hit"] += 1
                    stats_counts["success"] += 1
                except Exception as e:
                    print(f"\n[警告] 加载缓存 {job} 失败: {e}")
                    stats_counts["skip"] += 1

        data_list = cache_hit_data

        print(f"\n数据集统计: 总计 {stats_counts['total']} 个样本, "
              f"成功 {stats_counts['success']} 个, 缓存命中 {stats_counts['cache_hit']} 个, "
              f"跳过 {stats_counts['skip']} 个")

        if data_list:
            num_nodes_list = [d.x.size(0) for d in data_list]
            num_edges_list = [d.edge_index.size(1) // 2 for d in data_list]
            fracture_ratios = [(1.0 - d.y).sum().item() / d.y.size(0) if d.y.size(0) > 0 else 0
                          for d in data_list]
            print(f"铰接点数: min={min(num_nodes_list)}, max={max(num_nodes_list)}, "
                  f"avg={np.mean(num_nodes_list):.1f}")
            print(f"撑杆数:   min={min(num_edges_list)}, max={max(num_edges_list)}, "
                  f"avg={np.mean(num_edges_list):.1f}")
            print(f"断裂比例: min={min(fracture_ratios)*100:.1f}%, max={max(fracture_ratios)*100:.1f}%, "
                  f"avg={np.mean(fracture_ratios)*100:.1f}%")
            sample = data_list[0]
            print(f"节点特征维度: {sample.x.size(1)}")
            print(f"边特征维度:   {sample.edge_attr.size(1)}")

        data, slices = self.collate(data_list)
        torch.save((data, slices), self.processed_paths[0])
        print(f"数据集已保存至: {self.processed_paths[0]}")


# ======================================================================
# Main function
# ======================================================================
if __name__ == "__main__":
    os.makedirs(DATA_ROOT, exist_ok=True)

    print("=" * 60)
    print("第一步：计算全局归一化参数")
    print("=" * 60)

    norm_params = compute_norm_params(RAW_DATA_DIR, INP_DATA_DIR)
    print(f"\n归一化参数:\n{json.dumps(norm_params, indent=2, ensure_ascii=False)}")

    norm_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "norm_params_edge_level.json")
    save_norm_params(norm_params, norm_path)

    print("\n" + "=" * 60)
    print("第二步：构建纯几何特征撑杆图数据集")
    print("=" * 60)

    dataset = TrussStrutDataset(
        root=DATA_ROOT,
        norm_params=norm_params,
        inp_dir=INP_DATA_DIR,
    )
    print("\n数据集加载完成！")
