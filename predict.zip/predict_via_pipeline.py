# -*- coding: utf-8 -*-
import os
import sys
import json
import shutil
import pickle
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import TransformerConv, global_mean_pool
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
import numpy as np
import warnings
warnings.filterwarnings("ignore")

# =====================================================================
# 1. 引入原 Dataset 类
# =====================================================================
try:
    from test import TrussStrutDataset
except ImportError:
    raise ImportError("错误：在当前目录下找不到 test.py，请确保预测脚本与 test.py 在同一目录下")


# =====================================================================
# 2. 模型架构 
# =====================================================================
class LatticeGNN(torch.nn.Module):
    def __init__(self, node_in_dim=14, edge_in_dim=41, hidden_dim=128, dropout_rate=0.0): 
        super(LatticeGNN, self).__init__()
        self.conv1 = TransformerConv(node_in_dim, hidden_dim // 4, heads=4, concat=True, edge_dim=edge_in_dim, dropout=dropout_rate)
        self.conv2 = TransformerConv(hidden_dim, hidden_dim // 4, heads=4, concat=True, edge_dim=edge_in_dim, dropout=dropout_rate)
        self.conv3 = TransformerConv(hidden_dim, hidden_dim // 4, heads=4, concat=True, edge_dim=edge_in_dim, dropout=dropout_rate)
        
        self.global_context_1 = nn.Linear(hidden_dim, hidden_dim)
        self.global_context_2 = nn.Linear(hidden_dim, hidden_dim)
        
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim * 2 + edge_in_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(hidden_dim // 2, 1)
        )

    def forward(self, data):
        x, edge_index, edge_attr = data.x, data.edge_index, data.edge_attr
        batch_idx = data.batch if (hasattr(data, 'batch') and data.batch is not None) else torch.zeros(x.size(0), dtype=torch.long, device=x.device)
        
        x1 = F.relu(self.conv1(x, edge_index, edge_attr))
        g_emb1 = F.relu(self.global_context_1(global_mean_pool(x1, batch_idx)))
        x1 = x1 + g_emb1[batch_idx]
        
        x2 = F.relu(self.conv2(x1, edge_index, edge_attr))
        g_emb2 = F.relu(self.global_context_2(global_mean_pool(x2, batch_idx)))
        x2 = x2 + g_emb2[batch_idx]
        
        x3 = self.conv3(x2, edge_index, edge_attr) + x1 
        row, col = edge_index[0], edge_index[1]
        edge_features = torch.cat([x3[row], x3[col], edge_attr], dim=-1)
        return self.classifier(edge_features).squeeze(-1)


# =====================================================================
# 3. 动态单样本特征生成
# =====================================================================
def build_single_sample_pt(target_inp_path, norm_params):
    real_inp_dir = "./INP_DATA_DIR"
    real_raw_dir = "./RAW_DATA_DIR"
    
    os.makedirs(real_inp_dir, exist_ok=True)
    os.makedirs(real_raw_dir, exist_ok=True)
    
    inp_filename = os.path.basename(target_inp_path)
    base_name = os.path.splitext(inp_filename)[0]
    
    shutil.copy(target_inp_path, os.path.join(real_inp_dir, inp_filename))
    
    element_ids = []
    with open(target_inp_path, 'r', encoding='utf-8', errors='ignore') as f:
        in_element_section = False
        for line in f:
            line_strip = line.strip().upper()
            if line_strip.startswith('*ELEMENT'):
                in_element_section = True
                continue
            if line_strip.startswith('*') and not line_strip.startswith('*ELEMENT'):
                in_element_section = False
            if in_element_section and line_strip:
                parts = line_strip.split(',')
                if parts[0].isdigit():
                    element_ids.append(int(parts[0]))
                    
    mock_data = {
        "status": {eid: 1 for eid in element_ids}, 
        "broken_elements": [],
        "critical_ratio": 1.0,
        "load_steps": [0.0]
    }
    
    mock_pkl_path = os.path.join(real_raw_dir, f"{base_name}.pkl")
    with open(mock_pkl_path, 'wb') as f:
        pickle.dump(mock_data, f)
        
    tmp_root = "./tmp_single_predict"
    if os.path.exists(tmp_root):
        shutil.rmtree(tmp_root)
        
    dataset = TrussStrutDataset(
        root=tmp_root,
        norm_params=norm_params,
        inp_dir=real_inp_dir, 
        node_feature_group='Nall',
        edge_feature_group='Eall'
    ) 
    
    return dataset


# =====================================================================
# 4. 过滤渲染 
# =====================================================================
def render_directional_filtered_predictions(probs, edge_index, nodes, title, threshold=0.70):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    
    # 建立单元去重字典
    edge_dict = {}
    for i, (u, v) in enumerate(edge_index):
        edge_key = (min(u, v), max(u, v))
        if edge_key not in edge_dict:
            edge_dict[edge_key] = {
                'line': [nodes[u], nodes[v]], 
                'probs': []
            }
        edge_dict[edge_key]['probs'].append(probs[i])
            
    clean_lines, clean_probs = [], []
    for key, val in edge_dict.items():
        clean_lines.append(val['line'])
        clean_probs.append(np.max(val['probs']))
            
    clean_probs = np.array(clean_probs)

    # 左图：初始网格衬底
    ax1.add_collection(LineCollection(clean_lines, colors='gainsboro', linewidths=0.5, alpha=0.7))
    ax1.set_title(f"Initial Lattice Mesh ({title})", fontsize=10)
    
    # 右图：预测绘图衬底
    ax2.add_collection(LineCollection(clean_lines, colors='gainsboro', linewidths=0.4, alpha=0.1))
    
    # 🎯【核心修复】取消角度惩罚，所有直杆、斜杆统一采用传入的全局 threshold 进行判定
    high_risk_indices = [i for i in range(len(clean_probs)) if clean_probs[i] >= threshold]
    
    if high_risk_indices:
        pred_lines_high = [clean_lines[i] for i in high_risk_indices]
        pred_probs_high = clean_probs[high_risk_indices]
        
        # 统一线宽控制逻辑
        dynamic_linewidths = 1.0 + 2.0 * pred_probs_high
        
        # 渲染预测裂纹（如果您想和正常附件完全一致用红色，可将 'blue' 改为 'red'）
        lc_pred = LineCollection(pred_lines_high, colors='blue', linewidths=dynamic_linewidths, alpha=1.0)
        ax2.add_collection(lc_pred)
        ax2.set_title(f"GNN Predicted Crack Path (Threshold >= {threshold})", color='blue', fontsize=10)
    else:
        ax2.text(0.5, 0.5, f"No Cracks >= {threshold} After Filter", transform=ax2.transAxes, ha="center", va="center", color="gray")
        ax2.set_title(f"GNN Prediction (No Crack Detected)", fontsize=10)

    for ax in [ax1, ax2]:
        ax.set_aspect('equal')
        ax.autoscale()
        ax.axis('off')
        
    plt.tight_layout()
    save_path = f"./pipeline_predict_{os.path.splitext(title)[0]}_filtered_blue.png"
    
    # 保持高分辨率保存，并激活 plt.show() 弹窗交互
    plt.savefig(save_path, dpi=150)
    print(f"🎉 蓝色高精度预测图已成功导出: {save_path}")
    plt.show()  
    plt.close()


# =====================================================================
# 5. 主函数
# =====================================================================
def main():
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"[*] 当前激活的计算设备: {device}")
    
    model_weight_path = './best_lattice_gnn.pth' 
    json_param_path = './norm_params_edge_level.json'
    
    for path in [model_weight_path, json_param_path]:
        if not os.path.exists(path):
            raise FileNotFoundError(f"? 运行中断，未找到关键组件: '{path}'。")

    current_dir = "./" 
    inp_files = [f for f in os.listdir(current_dir) if f.lower().endswith('.inp')]
    
    if not inp_files:
        print("错误：在当前脚本同级目录下未找到任何后缀为 .inp 的文件！")
        return
    
    print(f"成功识别到 {len(inp_files)} 个待预测 INP 文件: {inp_files}")

    with open(json_param_path, "r", encoding="utf-8") as f:
        norm_params = json.load(f)

    model = LatticeGNN(node_in_dim=14, edge_in_dim=41, dropout_rate=0.0).to(device)
    model.load_state_dict(torch.load(model_weight_path, map_location=device))
    model.eval()
    print("预训练权重加载完毕\n")

    for idx, inp_filename in enumerate(inp_files, 1):
        full_inp_path = os.path.join(current_dir, inp_filename)
        print(f" ---------------- [{idx}/{len(inp_files)}] 正在处理: {inp_filename} ---------------- ")
        
        try:
            dataset = build_single_sample_pt(full_inp_path, norm_params)
            single_data = dataset[0].to(device)
            
            with torch.no_grad():
                logits = model(single_data)
                probs = torch.sigmoid(logits).cpu().numpy().flatten()
                
            print(f"   -> 盲测统计: Max Prob={probs.max():.4f} | Mean Prob={probs.mean():.4f}")

            max_coord = norm_params.get("max_coord", 100.0)
            node_coords = (single_data.x[:, 0:2].cpu().numpy()) * max_coord
            
            full_edge_index = single_data.edge_index.t().cpu().numpy()

            render_directional_filtered_predictions(
                probs=probs, 
                edge_index=full_edge_index, 
                nodes=node_coords, 
                title=inp_filename,
                threshold=0.65  
            )
            print(f"   -> [成功] 文件 {inp_filename} 预测分析完成。")
            
        except Exception as e:
            print(f"   -> [失败] 处理文件 {inp_filename} 时发生异常，跳过。错误信息: {e}")
            continue

    print("\n 所有自动识别的 INP 文件已处理完毕")

if __name__ == '__main__':
    main()